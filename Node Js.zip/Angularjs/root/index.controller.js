﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('Home.IndexController', Controller);

    function Controller($scope, $http) {
        $scope.userdetails = {};
        $scope.newuser = function(userdetails){
            $scope.userdetails.name = userdetails.name;
            $scope.userdetails.emailid = userdetails.emailid;
            $scope.userdetails.phone = userdetails.phone;
            $scope.userdetails.username = userdetails.username;
            $scope.userdetails.password = userdetails.password;
            alert(JSON.stringify($scope.userdetails));
            $http({
                method: 'POST',
                url: 'http://192.168.60.150:5000/userregisteration',
                headers: {"Authorization": "Basic " + btoa(":"), "Content-Type": "Application/json"},
                data: JSON.stringify($scope.userdetails)
            }).then(function(response) {
                alert(response);
            });
//              $http.post("http://192.168.60.150:5000/userregisteration", $scope.userdetails).success(function (response, status) {
//                  console.log('Success');
//                  $scope.list = response;
//              }).error(function (response, status) {
//                  console.log(response+'..Error..'+status);
//              });
        }

        initController();

        function initController() {
        }
    }

})();