var nsmarty = require('nsmarty');
var util = require('util');
var scriptfile = '';
var headered = 1;
var q = require('q');
var mysqli = require('./mysqli');
//var module = require('../module');
Date.prototype.addDays = function(days) {
var secsDay = 86400000; // there are 86400000 secs in 1 day
var time = this.getTime(); // number of milliseconds since midnight of January 1, 1970.
var newdate = new Date(time + (days * secsDay));
this.setDate(newdate.getDate());
    return newdate;
}


exports.checkLogin = function(req,res,id)
{
    if(typeof(req.session) === 'undefined' && id == 0)
    {
        res.writeHead(302, {
            'Location': '/login'
            //add other headers here...
        });
        res.end();return false;
    }
    else if(typeof(req.session.userid) === 'undefined' && id == 0)
    {

        res.writeHead(302, {
            'Location': '/login'
            //add other headers here...
        });
        res.end();return false;
    }
    else
    {
        if(req.session.userid > 0 && id == 1)
        {

            res.writeHead(302, {
                'Location': '/'
                //add other headers here...
            });
            res.end();return false;
        }
    }

}


exports.fetchCountries = function(mysql)
{
  $mysqli = {};
  strQuery = mysqli.mysqli($mysqli,267); 
    ////console.log(strQuery);
  var defered = q.defer();
  var escape_data = [0];
  query =  mysql.query(strQuery,escape_data,defered.makeNodeResolver());

  return defered.promise;
}

exports.tplFile = function(file)
{
	this.scriptfile = file;
}

exports.headerSet = function(data)
{

	this.headered = data;
}
exports.loadTemplateHeader = function(req,res,arr)
{
 arr.file = this.scriptfile;
 arr.headered = this.headered;	
 arr.loged = req.session;
 
  if(typeof(req.session.themeno) !== 'undefined') {
	 ////console.log("session theme set");
	 arr.themeno = req.session.themeno;
 }	
 else {
	 ////console.log("session theme not set");
	 req.session.themeno = 0;
	 arr.themeno = req.session.themeno;
 }
 
 arr._phrase = global.language_identifier.language.phrases;
 arr.nuller = null;
 if(typeof(arr.datenow) === 'undefined')
 {
     var dateFormat = require('dateformat');
     arr.datenow = new Date();
 } 
 ////console.log(arr._);
 uid = 0;
 user = require('./user'); 
 if(typeof(req.session) !== 'undefined')
 { 
   if(typeof(req.session.userid) !== 'undefined')
   {
     uid = req.session.userid;
   } 
 }
   arr.parseFloat = this.parseFloat;
   var dateFormat = require('dateformat');
   arr.dateFormat = dateFormat;
   arr.sumFloat = this.sumFloat;
   arr.currencyConverter = this.currencyConverter;
 //q.all([this.productCategories(arr.config.mysql,q),user.userInfo(req,arr.config.mysql,q,uid,['balance','reserve_amount'])]).then(function(results){
  //q.all([this.productCategories(arr.config.mysql,q)]).then(function(results){
  //var query = require('url').parse(req.url,true).query;
  ////console.log(req.url);
  var originalurl = req.originalUrl;
  arr.pageofjs = req.originalUrl;

  if(originalurl.indexOf("/dashboard") > -1 || originalurl == '/profile_settings')
  arr.pageofjs = '/dashboard/';
  ////console.log(arr.pageofjs);
 // arr.category = results[0][0];
  arr.userbalance = [];
  nsmarty.tpl_path = arr.config.path + '/templates/'; 
  ////console.log(2);
  nsmarty.clearCache(arr.file);
  ////console.log(this.scriptfile);
  if(!arr.headered)
  {
    function ajaxjsonrun(data)
    {
      
     res.setHeader('Content-Type', 'application/json');  
     res.end(JSON.stringify({ html: data }));
    }
  	stream = nsmarty.assigndata(arr.file,arr,ajaxjsonrun);
    
  }
  else
  {

   
    function onlyUnique(value, index, self) { 
    return self.indexOf(value) === index;
}
    delete defaultcss;
    defaultcss = ['parsley'];
    
     if(typeof(arr['externalcss']) !== 'undefined')
     {
        
        arr['external2css'] = arr['externalcss'].concat(defaultcss).filter(onlyUnique);
        delete arr['externalcss'];
     }
     else
     {     
           
           arr['external2css'] = defaultcss;
     } 
     delete defaultjs;
     defaultjs = ['parsley'];
    
     if(typeof(arr['externaljs']) !== 'undefined')     
     {        
        
        arr['external2js'] = arr['externaljs'].concat(defaultjs).filter(onlyUnique);;
        delete arr['externaljs'];
     }
     else
     {
          
           arr['external2js'] = defaultjs;
     } 
     arr['timer'] = 0;
    if(typeof(req.session.pid) !== 'undefined')
    {
      var moment = require('moment')
      var dateFormat = require('dateformat');
      var datenow = dateFormat(new Date(),"yyyy-mm-dd HH:MM:ss");
      var startDate = moment(req.session.temp_time_id, 'YYYY-M-DD HH:mm:ss')
      var endDate = moment(datenow, 'YYYY-M-DD HH:mm:ss');
      var secondsDiff = req.session.timer - endDate.diff(startDate, 'seconds');
      arr['timer'] = secondsDiff;
    }  
    
    res.setHeader('Content-Type', 'text/html; charset=UTF-8');   
   // //console.log(3);
  	stream = nsmarty.assign(arr.file,arr);

  	stream.pipe(res);

    ////console.log('asdasd');



  }
}