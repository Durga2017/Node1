
exports.mysqli = function(data,row)
{
     k = mysqli[row];
    
     for(var i in data)
     {
        
     	k = k.replace(new RegExp('{{'+i+'}}', 'g'), data[i]);
     	
     	
     }
     //console.log(k);
     return k;
}

// 1,

var mysqli = [];

mysqli[0]  = 'select email_id,login_password,active_status from person where email_id = "{{username}}" Limit 1';
mysqli[5]  = 'select * from person';
mysqli[25]  = 'select ?? from users where id = ? Limit 1';
mysqli[267] = 'select * from location where location_type = ? order by name asc';
mysqli['person'] = 'insert into person (first_name,last_name,email_id,mobile_number,date_of_birth,gender,display_name,city,login_password) values(?,?,?,?,?,?,?,?,?)';
mysqli['3edhetesting'] = 'insert into userregister (name,emailid,phone,username,password) values(?,?,?,?,?)';
//VENKAT START
mysqli['given_feedback'] = 'select * from company_preferences';

mysqli['product_service'] = 'select * from product_or_service where owning_business_entity_id=?';

mysqli['feedback_journey_stage'] = 'select * from customer_journey_stage_userdefined where owning_business_entity_id=?';

mysqli['customer_journey_process'] = 'select * from customer_journey_process_step_userdefined where journey_stage_ud_id=? and owning_business_entity_id=? order by process_step_display_seq_num asc';

mysqli['customer_feedback_questions_userdefined'] = 'select cfqu.*,rsct.language_id as rating_scale_language_id, rsct.rating_scale_chart_type_name,qt.language_id as questtype_language_id,qt.question_type_name,ftst.language_id as freetext_sizetype_language_id,ftst.free_text_size_type_name,ftst.field_size_num_chars,"" as "selected" from feedback_question_userdefined cfqu left join question_type as qt on cfqu.question_type_id=qt.question_type_id left join rating_scale_chart_type as rsct on cfqu.rating_scale_chart_type_id=rsct.rating_scale_chart_type_id left join free_text_size_type as ftst on cfqu.free_text_size_type_id=ftst.free_text_size_type_id left join customer_experience_kpi_userdefined as ekpi on cfqu.customer_experience_kpi_ud_id=ekpi.customer_experience_kpi_ud_id where cfqu.owning_business_entity_id=? and cfqu.journey_stage_ud_id=? and cfqu.process_step_ud_id=? and cfqu.active_question_yes_no="yes" and cfqu.active_question_naire_version_yes_no="yes" order by cfqu.question_display_seq_num asc';

mysqli['customer_feedback_questions_options'] = 'select * from feedback_question_resp_choice_userdefined where cfquestion_ud_id=? and owning_business_entity_id=? order by resp_display_seq_num asc';

mysqli['feedback_questions_options'] = 'select * from feedback_question_resp_choice_userdefined order by resp_display_seq_num asc'; // where cfquestion_ud_id=? and owning_business_entity_id=?

mysqli['feedback_question_choice'] = 'select * from feedback_question_resp_choice_userdefined where cfquestion_ud_id in(select cfquestion_ud_id from feedback_question_userdefined where owning_business_entity_id=? and journey_stage_ud_id=? and process_step_ud_id=? and active_question_yes_no="yes" and active_question_naire_version_yes_no="yes" order by question_display_seq_num asc) and owning_business_entity_id=? order by resp_display_seq_num asc';

mysqli['give_feedback_post'] = 'INSERT INTO feedback_post_details (post_originator_user_id, post_timestamp, seqnum, cfquestion_ud_id, cfrespchoice_ud_id, feedback_to_business_entity_id, process_step_ud_id, respchoice_story_text,other_choice_text) VALUES ?';

/*mysqli['post_header'] = 'INSERT INTO feedback_post_header (post_originator_user_id,post_timestamp,product_id,feedback_to_business_entity_id,feedback_status_id,journey_stage_ud_id,topic,interaction_date,chatrequest,callback_request,num_upvotes,num_views,num_comments,report_abuse_flag,nps,overall_experience_story_text) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'; */

mysqli['post_header'] = 'INSERT INTO feedback_post_header (post_originator_user_id,post_timestamp,product_id,feedback_to_business_entity_id,feedback_status_id,journey_stage_ud_id,topic,interaction_date,num_upvotes,num_views,num_comments,nps,overall_experience_story_text,callback_request) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)'; 

mysqli['post_notification'] = "INSERT INTO notification (user_id,time_stamp,event_id,post_originator_user_id,post_time_stamp,post_type_id,owning_business_entity_id,active_status) VALUES (?,?,?,?,?,?,?,?)";

mysqli['employee_department'] = 'select * from employee_department where owning_business_entity_id=?';

mysqli['employee_information'] = 'select emp.*,psn.country_id,psn.currency_id,psn.language_id as person_language_id,psn.email_id,psn.mobile_number,psn.active_status,psn.profile_picture,psn.first_name,psn.last_name,psn.display_name,psn.gender,psn.phone_number,psn.date_of_birth,psn.city,psn.recovery_phone_number,psn.recovery_email_id,psn.number_of_logins,psn.last_log_in_date,"" as "selected"	from employee emp inner join person psn on emp.person_id=psn.person_id where emp.owning_business_entity_id=? and psn.active_status="Active"';

mysqli['customer_KPI_value'] = 'select * from customer_experience_kpi_userdefined where customer_experience_kpi_ud_id=? and owning_business_entity_id=?';

mysqli['action_notify_becategory'] = 'select * from business_entity_category';

mysqli['action_notify_company'] = 'select * from business_entity_company_info where business_entity_id in (?) and active_status="Active"';

mysqli['action_notify_person'] = 'select be.business_entity_id as business_entity_id,be.be_type_id as be_type_id,person.*,person.display_name as business_entity_company_name from business_entity be left join person on be.person_id=person.person_id where be.business_entity_id in(?) and person.active_status="Active"';

mysqli['action_notify_bentity'] = 'select * from business_entity where business_entity_id=? and active_status="Active"';

mysqli['action_notify_berelationship'] = 'select be.* from business_entity be inner join business_entity_relationship ber on be.business_entity_id=ber.business_entity_id_2 where ber.business_entity_2_category_id=? and ber.active_status="Active" and be.active_status="Active" group by ber.business_entity_2_category_id';

mysqli['customer_segment'] = 'select * from customer_segment where owning_business_entity_id=?';

mysqli['action_notify_beemployee'] = 'select emp.*,psn.country_id,psn.currency_id,psn.language_id as person_language_id,psn.email_id,psn.mobile_number,psn.active_status,psn.profile_picture,psn.first_name,psn.last_name,psn.display_name,psn.gender,psn.phone_number,psn.date_of_birth,psn.city,psn.recovery_phone_number,psn.recovery_email_id,psn.number_of_logins,psn.last_log_in_date,"" as "selected" from employee emp inner join person psn on emp.person_id=psn.person_id where emp.owning_business_entity_id=? and psn.active_status="Active"';

mysqli['notify_employee_post'] = "INSERT INTO feedback_post_response_chain (post_originator_user_id, post_timestamp,responder_user_id,response_timestamp, feedback_to_business_entity_id, response_text, notify_text_visible_to_post_originator_yes_no) VALUES (?,?,?,?,?,?,?)";

mysqli['get_post_type_id'] = 'select * from post_type where post_type_description like ?';

mysqli['get_guideline'] = 'select * from post_guidelines_userdefined where owning_business_entity_id=? and post_type_id=? and be_category_id=? and berr_id=?';

mysqli['get_significant_even'] = 'select * from significant_event where active_status like "Active" and event_name like ?';

mysqli['get_feedback_badge'] = 'select * from fleeting_badge where digital_reputation_level_id=? and event_id=?';

mysqli['get_user_digital_level'] = 'select udr.*,drb.digital_reputation_badge_description,drb.digital_reputation_badge_icon from user_digital_reputation udr left join digital_reputation_badge drb on udr.current_digital_reputation_badge_id=drb.digital_reputation_badge_id where udr.user_id=? and udr.owning_business_entity_id=? order by udr.time_stamp desc limit 1';

mysqli['get_drpoint_rules'] = 'select drpr.*,se.event_name from digital_reputation_point_rules drpr inner join significant_event se on drpr.event_id=se.event_id where drpr.active_status like "Active" and se.active_status like "Active" and se.event_name like "feedback - complete a process step" or se.event_name like "feedback - complete an activity"';

/* Upvote digital repution */
mysqli['get_digital_point_rules'] = 'select drpr.*,se.event_name from digital_reputation_point_rules drpr inner join significant_event se on drpr.event_id=se.event_id where drpr.active_status like "Active" and se.active_status like "Active" and se.event_name like ?';

/*mysqli['get_user_drpoint'] = 'SELECT udr.last_qualified_event_id,count(udr.last_qualified_event_id),se.event_name FROM `user_digital_reputation` udr inner join significant_event se on se.event_id=udr.last_qualified_event_id where udr.owning_business_entity_id=? and udr.user_id=? group by udr.last_qualified_event_id';*/

/*mysqli['get_drevent_combination'] = 'select drec.*,se.event_name from digital_reputation_event_combination drec inner join significant_event se on drec.event_id=se.event_id where se.active_status like "Active" and (se.event_name like "referral given" or se.event_name like "company buzz" or se.event_name like "appreciation given" or se.event_name like "feedback given" or se.event_name like "idea given" or se.event_name like "issue given" or se.event_name like "max chirps") and drec.digital_reputation_event_combination_id=?';*/

mysqli['get_drevent_combination'] ='select drl.*,drec.event_id,drec.event_threshold_value,drb.digital_reputation_badge_icon,se.event_name from digital_reputation_level drl inner join digital_reputation_event_combination drec on drl.digital_reputation_event_combination_id = drec.digital_reputation_event_combination_id left join significant_event se on drec.event_id = se.event_id left join digital_reputation_badge drb on drl.digital_reputation_badge_id = drb.digital_reputation_badge_id where drl.digital_reputation_level_id =?';

mysqli['get_user_drpoint'] = 'SELECT udr.last_qualified_event_id,count(udr.last_qualified_event_id) as event_count,se.event_name FROM `user_digital_reputation` udr inner join significant_event se on se.event_id=udr.last_qualified_event_id group by udr.last_qualified_event_id';

mysqli['post_user_digital_reput'] = "INSERT INTO user_digital_reputation (user_id,time_stamp,current_digital_reputation_level_id,current_digital_reputation_badge_id, owning_business_entity_id, last_qualified_event_id, accumulated_digital_reputation_points) VALUES (?,?,?,?,?,?,?)";

mysqli['notify_list'] = 'INSERT INTO notify_list (post_type_id, post_user_id,post_timestamp, seqnum, notify_to_business_entity_id, notify_to_business_entity_user_id) VALUES ?';

mysqli['get_share_community'] = 'select * from community_type';

mysqli['feedback_share_post'] = "INSERT INTO feedback_post_response_chain (post_originator_user_id, post_timestamp,responder_user_id,response_timestamp, feedback_to_business_entity_id, response_text, copy_to_employee_community,copy_to_industry_community) VALUES (?,?,?,?,?,?,?,?)";

mysqli['get_question_type'] = 'select * from question_type';

mysqli['get_group_header'] = 'select * from group_header where active_status="Active" and owning_business_entity_id=?';

//Poll part
mysqli['get_dealer_question'] = 'select pq.*,ps.product_name from poll_question pq left join product_or_service ps on pq.product_id=ps.product_id where pq.active_status="Active" and pq.owning_business_entity_id=?';

mysqli['get_dealer_bentity'] = 'select be.* from business_entity be left join poll_question pq on be.business_entity_id=pq.owning_business_entity_id where pq.active_status="Active" and pq.owning_business_entity_id=? group by be.business_entity_id';

mysqli['get_dealer_choice'] = 'select pc.* from poll_choices pc inner join  poll_question pq  on pc.poll_title=pq.poll_title and pc.poll_start_date = pq.poll_start_date and pc.creator_user_id =pq.creator_user_id where pq.active_status="Active" and pc.owning_business_entity_id=? and pq.owning_business_entity_id=?';

mysqli['dealer_create_poll_question'] = "INSERT INTO poll_question (poll_title,poll_start_date,creator_user_id,active_status,poll_end_date,poll_question_text,single_or_multiple_choice_selection_flag,insert_picture,insert_video,owning_business_entity_id,product_id,target_berr_id,group_name,group_creator_user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

mysqli['dealer_create_poll_choices'] = 'INSERT INTO poll_choices (poll_title, poll_start_date,creator_user_id, seq_num, poll_choice_text,owning_business_entity_id,target_berr_id) VALUES ?';

// Venkat END

mysqli['Feedback_comment_update'] = 'insert into feedback_post_response_chain(post_originator_user_id,post_timestamp,response_timestamp,responder_user_id,response_text) values(?,?,?,?,?)';
mysqli['feedback_comments_post_callback'] = 'UPDATE feedback_post_header SET  callback_request = ? WHERE post_originator_user_id = ? and post_timestamp = ?';
mysqli['feedback_comments_post_chatreq'] = 'UPDATE feedback_post_header SET  chatrequest= ? WHERE post_originator_user_id = ? and post_timestamp = ?';
mysqli['feedback_comments_post_update_value'] = 'SELECT num_comments FROM feedback_post_header where post_originator_user_id=? and post_timestamp=?';
mysqli['feedback_comments_post_update_value_set'] = 'UPDATE feedback_post_header SET num_comments = ? WHERE post_originator_user_id = ? and post_timestamp = ?';
mysqli['feedback_list_view_detail'] = 'SELECT num_views FROM feedback_post_header where post_originator_user_id=? and post_timestamp=?';
mysqli['feedback_comments_post_upvote'] = 'UPDATE feedback_post_header SET  num_upvotes = ? WHERE post_originator_user_id = ? and post_timestamp = ?';
//mysqli['Feedback_comment_upvote'] = 'UPDATE feedback_post_response_chain SET  upvote_flag = ?,responder_user_id = ?,response_timestamp = ? WHERE post_originator_user_id = ? and post_timestamp = ?';
mysqli['Feedback_comment_upvote'] = 'UPDATE feedback_post_response_chain SET  upvote_flag = ?,responder_user_id = ?,response_timestamp = ? WHERE post_originator_user_id = ? and post_timestamp = ?';
mysqli['feedback_list_view'] = 'UPDATE feedback_post_header SET  num_views = ? WHERE post_originator_user_id = ? and post_timestamp = ?';
mysqli['Feedback_comment_replay_one'] = 'insert into feedback_post_response_chain(post_originator_user_id,post_timestamp,responder_user_id,response_timestamp,response_text,reply_to_user_id,reply_to_timestamp) values(?,?,?,?,?,?,?)';
mysqli['feedback_comments_post_upvote_insert'] = 'insert into feedback_post_response_chain(post_originator_user_id,post_timestamp,responder_user_id,response_timestamp,upvote_flag,num_upvotes_for_response) values(?,?,?,?,?,?)';
mysqli['feedback_upvote_count'] = 'SELECT num_upvotes FROM feedback_post_header where post_originator_user_id=? and post_timestamp=?';
mysqli['feedback_comments_post_view_insert'] = 'insert into feedback_post_response_chain(post_originator_user_id,post_timestamp,responder_user_id,response_timestamp,view_flag) values(?,?,?,?)';
mysqli['Feedback_comment_upvote_insert'] = 'insert into feedback_post_response_chain(post_originator_user_id,post_timestamp,reply_to_user_id,reply_to_timestamp,responder_user_id,response_timestamp,response_text) values(?,?,?,?,?,?,?)';
mysqli['Feedback_upvote_users'] = 'SELECT fprc.post_originator_user_id,fprc.post_timestamp,fprc.responder_user_id,fprc.upvote_flag,p.display_name FROM feedback_post_response_chain as fprc LEFT JOIN person as p on p.person_id=fprc.responder_user_id';
//mysqli['feedback_comment_replay_two_value'] = 'SELECT p.display_name,p.person_id,fprc.post_originator_user_id,fprc.post_timestamp,fprc.responder_user_id,fprc.response_timestamp,fprc.reply_to_user_id,fprc.reply_to_timestamp,fprc.response_text,fprc.num_upvotes_for_response FROM feedback_post_response_chain as fprc LEFT JOIN person as p on p.person_id=fprc.reply_to_user_id';

mysqli['feedback_comment_replay_two_value'] = 'SELECT p.display_name,p.person_id,fprc.post_originator_user_id,fprc.post_timestamp,fprc.responder_user_id,fprc.response_timestamp,fprc.reply_to_user_id,fprc.reply_to_timestamp,fprc.response_text,fprc.num_upvotes_for_response FROM feedback_post_response_chain as fprc LEFT JOIN person as p on p.person_id=fprc.responder_user_id Where fprc.responder_user_id!=? AND fprc.response_timestamp!=? AND fprc.reply_to_user_id!=? AND fprc.reply_to_timestamp!=?';

// Anbarasan 06 Sept 2016
mysqli['feedback_comment_replay_two_upvote_count'] = 'SELECT COUNT(fprc.num_upvotes_for_response) FROM feedback_post_response_chain as fprc WHERE fprc.post_originator_user_id = ? AND fprc.post_timestamp = ? AND fprc.responder_user_id = ? AND fprc.response_timestamp = ? AND upvote_flag = ?';
mysqli['feedback_comment_replay_two_upvote'] = 'insert into feedback_post_response_chain(post_originator_user_id,post_timestamp,responder_user_id,response_timestamp,reply_to_user_id,reply_to_timestamp,response_text) values(?,?,?,?,?,?,?)';

// Anbarasan 08 Sept 2016
mysqli['feedback_post_type'] = 'SELECT pt.post_type_id FROM post_type as pt WHERE pt.post_type_description = ?';
mysqli['addimages'] = 'insert into post_picture_video_objects(post_type_id,post_user_id,post_timestamp,picture_url,seq_num)values(?,?,?,?,?)';


mysqli['feedbackPostUpvote_Insert']='INSERT INTO feedback_post_response_chain (post_originator_user_id,post_timestamp,responder_user_id,response_timestamp,upvote_flag,num_upvotes_for_response)VALUES(?,?,?,?,?,?)';
mysqli['feedbackCommentsPostUpvote'] = 'UPDATE feedback_post_header SET  num_upvotes = ? WHERE post_originator_user_id = ? and post_timestamp = ?';
mysqli['feedbackCommentsPostCallRequest'] = 'UPDATE feedback_post_header SET  callback_request = ? WHERE post_originator_user_id = ? and post_timestamp = ?';
mysqli['FeedbackUpvotesDetains']='SELECT fph.post_originator_user_id,fph.post_timestamp,fph.num_upvotes,fph.num_views,fph.num_comments,fph.chatrequest,fph.callback_request FROM feedback_post_header fph WHERE post_originator_user_id=1';
mysqli['FeedbackUpvoteFlag']='SELECT f1.post_originator_user_id,f1.post_timestamp,f1.upvote_flag FROM feedback_post_response_chain f1 where response_timestamp=(SELECT max(response_timestamp) FROM feedback_post_response_chain where post_timestamp=f1.post_timestamp and upvote_flag<>"") group by post_originator_user_id, post_timestamp';
mysqli['FeedbackUpvotes_Upvotes']='SELECT fprc.post_originator_user_id,fprc.post_timestamp,per.display_name FROM feedback_post_response_chain fprc INNER JOIN person per ON fprc.post_originator_user_id=person_id WHERE fprc.post_originator_user_id=1 AND fprc.upvote_flag<>""';
mysqli['chat_get_data']='Select chat_history_text,responder_user_id,response_timestamp From feedback_post_response_chain WHERE post_originator_user_id=? AND post_timestamp=? AND chat_history_text!=? ORDER BY response_timestamp';

mysqli['chat_get_data_company']='Select chat_history_text,responder_user_id,response_timestamp From feedback_post_response_chain WHERE post_originator_user_id=? AND post_timestamp=? AND chat_history_text!=? ORDER BY response_timestamp';

mysqli['feedback_list_chat']='INSERT INTO feedback_post_response_chain (post_originator_user_id,post_timestamp,responder_user_id,response_timestamp,chat_history_text)VALUES(?,?,?,?,?)';

mysqli['chat_history_details']='SELECT fprc.*,NOW() FROM feedback_post_response_chain as fprc WHERE fprc.chat_history_text !=? ORDER BY fprc.response_timestamp ASC';

mysqli['feedbackPostUpvote_Insert']='INSERT INTO feedback_post_response_chain (post_originator_user_id,post_timestamp,responder_user_id,response_timestamp,upvote_flag,num_upvotes_for_response)VALUES(?,?,?,?,?,?)';
mysqli['feedbackPostUpvote_Update']='UPDATE feedback_post_response_chain SET upvote_flag=?,response_timestamp=? WHERE  (upvote_flag="No" OR upvote_flag="Yes") AND post_originator_user_id=? AND post_timestamp=? AND responder_user_id=?';
mysqli['feedbackCommentsPostUpvote'] = 'UPDATE feedback_post_header SET  num_upvotes = ? WHERE post_originator_user_id = ? and post_timestamp = ?';
mysqli['feedbackCommentsPostCallRequest'] = 'UPDATE feedback_post_header SET  callback_request = ? WHERE post_originator_user_id = ? and post_timestamp = ?';

mysqli['feedback_calback_status'] = 'SELECT fph.callback_request,beci.call_back_request as company_call_back_request,beci.chat_request as company_chat_request from feedback_post_header as fph LEFT JOIN business_entity_company_info as beci on beci.business_entity_id=fph.feedback_to_business_entity_id WHERE fph.post_originator_user_id=? AND fph.post_timestamp=?';

