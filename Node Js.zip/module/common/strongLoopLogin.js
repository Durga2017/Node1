var  util    = require('util');
var dateFormat = require('dateformat');
var q = require('q');
//var mysqli1 = require('./mysqli');
var db = require('./connection/Login_connection');
var common = require('./../common');
var url = require('url');

exports.strongLoopLogin = function(req,mysql,q)
{
  console.log(req.body);
    $db =  {};
    strQuery = db.db($db,'strongLoopLogin');
    var defered = q.defer();
    escape_data =[req.body.username];
    //escape_data =['rosa@gmail.com'];
    query =  mysql.query(strQuery,escape_data,defered.makeNodeResolver());
    //console.log(query);
    query.on('error',function(err){
        //console.log(err.stack);
        throw err;
    })
    return defered.promise;
}
exports.check_user_auth = function(req,mysql,q,person_id)
{
    $db =  {};
    strQuery = db.db($db,'check_user_auth');
    var defered = q.defer();
    //escape_data =[req.body.username];
    escape_data =[person_id];
    query =  mysql.query(strQuery,escape_data,defered.makeNodeResolver());
    console.log(query.sql);
    query.on('error',function(err){
        //console.log(err.stack);
        throw err;
    })
    return defered.promise;
}
exports.check_Company_user = function(req,mysql,q,person_id)
{
    $db =  {};
    strQuery = db.db($db,'check_Company_user');
    var defered = q.defer();
    //escape_data =[req.body.username];
    escape_data =[person_id];
    query =  mysql.query(strQuery,escape_data,defered.makeNodeResolver());
    console.log(query.sql);
    query.on('error',function(err){
        //console.log(err.stack);
        throw err;
    })
    return defered.promise;
}