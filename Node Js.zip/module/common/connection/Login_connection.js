
exports.db = function(data,row)
{
     k = db[row];
    
     for(var i in data)
     {
        
     	k = k.replace(new RegExp('{{'+i+'}}', 'g'), data[i]);
     	
     	
     }
     return k;
}

var db = [];

db['strongLoopLogin']  = 'select * from person where email_id = ?';
db['check_user_auth']  = 'select * from authorised_user where person_id = ?';
db['check_Company_user']  = 'select * from employee where person_id = ?';