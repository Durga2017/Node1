var  util    = require('util');
     
var q = require('q');
var mysqli = require('./mysqli');
var common = require('./common');
var url = require('url');
exports.userInfo = function(req,mysql,q,id,field)
{
  if(id == 0)
  {
    id = (typeof(req.session) !== 'undefined' )  ? req.session.userid : 0;
  }  
  if(field == '')
  {
    field = '*';
  } 
  
  $mysqli =  {};
  strQuery = mysqli.mysqli($mysqli,25); 
  var escape_data = [field,id];
  var defered = q.defer();


  query =  mysql.query(strQuery,escape_data,defered.makeNodeResolver());

  return defered.promise;
  
}

exports.newuser = function(mysql,req, res)
{
	$mysqli = {};
    strQuery = mysqli.mysqli($mysqli,'person');
	var defered = q.defer();
    var md5 = require('MD5');
    var password_salt = '12345'
    var password = md5(md5(req.body.password)+password_salt);
	escape_data =[req.body.f_name,req.body.l_name,req.body.email_id,req.body.m_no,req.body.dob,req.body.gender1,req.body.d_name,req.body.city,password];
	query =  mysql.query(strQuery,escape_data,defered.makeNodeResolver());
	query.on('error',function(err){
	throw err;
	});
	
	return defered.promise;
}

// Test

exports.testregister = function(mysql,req, res)
{
    $mysqli = {};
    console.log(typeof(req.body));
    strQuery = mysqli.mysqli($mysqli,'3edhetesting');
    var defered = q.defer();
    var md5 = require('MD5');
    var password_salt = '12345'
    var password = md5(md5(req.body.password)+password_salt);
    escape_data =[req.body.name,req.body.emailid,req.body.phone,req.body.username,password];
    query =  mysql.query(strQuery,escape_data,defered.makeNodeResolver());

    console.log(query.sql);

    query.on('error',function(err){
        throw err;
    });

    return defered.promise;
}

exports.user = function(req,mysql,q)
{
    $mysqli =  {};
    strQuery = mysqli.mysqli($mysqli,'user_data');
    var defered = q.defer();
    escape_data =[1];
    query =  mysql.query(strQuery,escape_data,defered.makeNodeResolver());
    query.on('error',function(err){
        console.log(err.stack);
        throw err;
    })
    return defered.promise;
}
// End


