var http = require('http');
var express = require('express');
var session = require('cookie-session');
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var multer = require('multer');
var maxfluence = require('./maxfluence');

var app = express();
app.use(require('express-domain-middleware'));
app.use(session({ secret: 'keyboard cat', cookie: { maxAge: 60000000 }, resave: true, saveUninitialized: true }))

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(cookieParser('cookiecnx'));
app.use(session({secret: '1234567890QWERTY', cookie:{maxAge:60000000}}));
app.use(express.static(path.join(__dirname, 'public')));
app.use(maxfluence.maxfluence());

configure = require('./configure')
//default setters
config = configure.app()
$arr = {
  config : config
};

var index = require('./routes/index');



app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods','GET,PUT,POST,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers','Content-Type,Authorization');
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Accept");
  //res.header('content-type: application/json; charset=utf-8');
  next();
});
var enableCORS = function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With, *');

  // intercept OPTIONS method
  if ('OPTIONS' == req.method) {
    res.send(200);
  } else {
    next();
  };
};
app.use('/',index);
app.use('/index',index);

module.exports = app;
var server = http.createServer(app);

var fs = require('fs');
var util = require('util');
var log_file = fs.createWriteStream(__dirname + '/Debug.log', {flags : 'w'});
var log_stdout = process.stdout;

console.log = function(d) { //
  log_file.write(util.format(d) + '\n');
  log_stdout.write(util.format(d) + '\n');
};

server.listen(5000);

// use socket.io
var io = require('socket.io').listen(server);

//turn off debug
io.set('log level', 1);

// define interactions with client
io.sockets.on('connection', function(socket){    //send data to client
socket.on('bidAddtime', function(msg){

//console.log(msg);
io.sockets.emit('bidAddtime',  msg);

//console.log('#my'+msg);
});

});