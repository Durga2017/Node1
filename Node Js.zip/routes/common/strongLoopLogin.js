/*==========================================================================*\
|| ######################################################################## ||
|| # Maxfluence Software [*]version[*] Build [*]build[*]
|| # -------------------------------------------------------------------- # ||
|| # Customer License # [*]license[*]
|| # -------------------------------------------------------------------- # ||
|| # Copyright ©2016-[*]year[*] maxfluence Inc. All Rights Reserved.      # ||
|| # This file may not be redistributed in whole or significant part.     # ||
|| # ----------------- ILANCE IS NOT FREE SOFTWARE ---------------------- # ||
|| # http://www.maxfluence.com | support@maxfluence.com 				  # ||
|| # -------------------------------------------------------------------- # ||
|| ######################################################################## ||
\*==========================================================================*/
var q = require('q');
var express = require('express');
var reload = require('reload');
var sprintf = require('sprintf').sprintf;
var app = express.Router();
var dateFormat = require('dateformat');
var async = require('async');
var paypal = require('paypal-rest-sdk');
var db = require('../../module/common/connection/Login_connection');
var forEach = require('async-foreach').forEach;
var waterfall = require('async-waterfall');

app.post('/login',function(req,res) {
	console.log('connecting..........................');
	waterfall([
		function (callback) {
			var strongLoopLogin1 = require('../../module/common/strongLoopLogin');
			q.all([strongLoopLogin1.strongLoopLogin(req,config.mysql,q)]).then(function(results){
				var strongLoopLogin = results[0][0];
				if(strongLoopLogin=='')
				{
					//res.status(500).send({ error: "boo:(" });
					res.json({"errorMsg":"Please check your E-mail id"});
					//res.json("errorMsg" ,{"errorMsg":"Please check your E-mail id"});
				}else{
					callback(null, strongLoopLogin);
				}
			});
		},
		function( strongLoopLogin, callback) {
			var strongLoopLogin1 = require('../../module/common/strongLoopLogin');
			console.log(strongLoopLogin[0].email_id);
			//if(strongLoopLogin[0].email_id==req.body.username)
			if(strongLoopLogin!='')
			{
				var person_id = strongLoopLogin[0].person_id;
				q.all([strongLoopLogin1.check_user_auth(req,config.mysql,q,person_id)]).then(function(results){
				var check_user_auth = results[0][0];
				if(check_user_auth!='')
				{
					q.all([strongLoopLogin1.check_Company_user(req,config.mysql,q,check_user_auth[0].person_id)]).then(function(results2){
						if(results2[0][0]=='')
						{
							var email_id = strongLoopLogin[0].email_id;
							var person_id = strongLoopLogin[0].person_id;
							var mobile_number = strongLoopLogin[0].mobile_number;
							var is_super_user_flag = strongLoopLogin[0].is_super_user_flag;
							var profile_picture = strongLoopLogin[0].profile_picture;
							var display_name = strongLoopLogin[0].display_name;
							var user_id = check_user_auth[0].user_id;
							var authorising_business_entity_id = check_user_auth[0].authorising_business_entity_id;
							res.json({"User_Status":"Customer","Email":email_id,"mobile_number":mobile_number,"is_super_user_flag":is_super_user_flag,"profile_picture":profile_picture,"display_name":display_name,"authorising_business_entity_id":authorising_business_entity_id,"user_id":person_id});
						}else{
							var email_id = strongLoopLogin[0].email_id;
							var person_id = strongLoopLogin[0].person_id;
							var mobile_number = strongLoopLogin[0].mobile_number;
							var is_super_user_flag = strongLoopLogin[0].is_super_user_flag;
							var profile_picture = strongLoopLogin[0].profile_picture;
							var display_name = strongLoopLogin[0].display_name;
							var user_id = check_user_auth[0].user_id;
							var authorising_business_entity_id = check_user_auth[0].authorising_business_entity_id;
							res.json({"User_Status":"Company","Email":email_id,"mobile_number":mobile_number,"is_super_user_flag":is_super_user_flag,"profile_picture":profile_picture,"display_name":display_name,"authorising_business_entity_id":authorising_business_entity_id,"user_id":person_id});
						}
					});
				}else{
					res.json({"errorMsg":"You are currently not authorized"});
				}
				callback(null, check_user_auth);
			});
			}else{
				res.json({"errorMsg":"Please contact Maxfluence"});
			}
		},
		function( check_user_auth, callback) {
			//console.log(check_user_auth);
		}
	], function (err, result) {
		//console.log(result);
	});
});

module.exports = app;