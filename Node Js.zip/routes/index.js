var q = require('q');
var fs = require('fs');
var express = require('express');
var reload = require('reload');
var sprintf = require('sprintf').sprintf;
var app = express.Router();
var dateFormat = require('dateformat');
var async = require('async');
var paypal = require('paypal-rest-sdk');
var mysqli = require('../module/mysqli');

// Maxfluence Function Srart


app.get('/servertime', function (req, res) {
	var dateFormat = require('dateformat');
	datenow = dateFormat(new Date(), "yyyy-mm-dd HH:MM:ss");
	res.send(datenow);
	res.end();
	return false;

});

app.post('/userregisteration', function(req, res){
    console.log(req.body);
	var users = require('../module/user');
	q.all([users.testregister(config.mysql,req, res)]).then(function(results){
		res.json({"Details":req.body});
	});


});
app.get('/',function(req,res)
{
	console('test connnn');
	// //res.render('customer/customer_dashboard.tpl');
  	common.tplFile('index.html');
	common.headerSet(1);
	common.loadTemplateHeader(req, res, $arr);
});

app.get('/log',function(req,res)
{
	console.log('Anbarasannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn');
  common.tplFile('../debug.log');
    common.headerSet(1);
    common.loadTemplateHeader(req, res, $arr);
});

app.get('/Feedback-list',function(req,res)
{
  common.tplFile('customer/feedback-list.tpl');
    common.headerSet(1);
    common.loadTemplateHeader(req, res, $arr);
});

app.get('/Event',function(req,res)
{
	var admin = require('../module/admin');
	q.all([admin.allteam(config.mysql,req, res),admin.home_team(config.mysql,req, res,req.param('home_team'))]).then(function(results){
		 $arr['home_team'] =  results[0][0];
	$arr['select_team']=results[0][0];
	common.tplFile('mbuzz_event.tpl');
    common.headerSet(1);
    common.loadTemplateHeader(req, res, $arr);
	});
});

app.get('/Registration',function(req,res)
{
  common.tplFile('users.tpl');
    common.headerSet(1);
    common.loadTemplateHeader(req, res, $arr);
});

// test guide

app.get('/test_regstraton',function(req,res)
{
	common.tplFile('form.tpl');
	common.headerSet(1);
	common.loadTemplateHeader(req, res, $arr);
});

app.post('/connecting', function(req, res){
	console.log('Connecting..............................................');
});



// END

app.post('/registration', function(req, res){
	var users = require('../module/user');
      q.all([users.newuser(config.mysql,req, res)]).then(function(results){
		  $arr['successss'] = '1';
		  res.writeHead(302, {     
			       'Location': '/'
			      });
			      res.end();return false;
	  });
     
  
});
app.get('/register',function(req,res)
{
	var user = require('../module/user');
	q.all([user.user(req,config.mysql,q)]).then(function(results){
		//JSON.stringify(results[0][0]);
		//$arr['feedback_list'] = results[0][0];
		$arr['register'] = results[0][0];
		console.log(results[0][0]);
		common.tplFile('form.tpl');
		common.headerSet(1);
		common.loadTemplateHeader(req, res, $arr);
	});
});
app.post('/FeedbackPostUpvote_Update',function(req,res)
{
    var feedback = require('../module/feedback');
    if(req.body.isUpvoted==0)
    {
        console.log('insert');
        q.all([feedback.feedbackPostUpvote_Insert(req,config.mysql,q)]).then(function(results){
            q.all([feedback.feedbackPostUpvotes_Update(req,config.mysql,q)]).then(function(results){
                    res.json('success');
            });
        });
    }
    else
    {
        console.log('update');
        q.all([feedback.feedbackPostUpvote_Update(req,config.mysql,q)]).then(function(results){
            q.all([feedback.feedbackPostUpvotes_Update(req,config.mysql,q)]).then(function(results){
                    res.json('success');
            });
    });
    }
    
});





app.post('/FeedbackPostCallRequest_Update',function(req,res)
{
	var feedback = require('../module/feedback');
	q.all([feedback.FeedbackPostCallRequest_Update(req,config.mysql,q)]).then(function(results){
		res.json('success');
	});
});

module.exports = app;

